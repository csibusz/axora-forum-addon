<?php
require_once __DIR__ . '/../includes/auth_check_admin.php';
$db = require __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
renderAdmin('login', []);

if (empty($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

$boards = $conn->query("SELECT * FROM forum_boards ORDER BY id ASC")->fetch_all(MYSQLI_ASSOC);
$resultt = $conn->query("SELECT * FROM website_info WHERE id = 1");
$info = $resultt->fetch_assoc();

$fields = ['title', 'description', 'keywords', 'website_name', 'analytics'];
$total = count($fields);
$filled = 0;

foreach ($fields as $field) {
    if (!empty(trim($info[$field]))) {
        $filled++;
    }
}

$percentage = round(($filled / $total) * 100);
$barColor = match (true) {
    $percentage < 40 => 'bg-danger',
    $percentage < 80 => 'bg-warning',
    default => 'bg-success'
};
?>

<style>
  html, body {
    height: 100%;
    margin: 0;
    padding: 0;
  }

  body {
    display: flex;
    flex-direction: column;
    
  }

  .container-fluid {
    flex: 1;
  }
</style>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<body >
<div class="container-fluid">
  <div class="row">
    <?php include 'themes/admin/navbar.php'; ?>
    <main class="col-md-10 ms-sm-auto px-md-4 py-4">
      <?php include 'themes/admin/menu.php'; ?>

      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Forum Boards</h2>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addBoardModal">➕ New Board</button>
      </div>

      <?php if ($boards): ?>
        <div class="table-responsive">
          <table class="table table-striped table-bordered">
            <thead class="table-dark">
              <tr>
                <th>ID</th>
                <th>Slug</th>
                <th>Title</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($boards as $b): ?>
                <tr id="boardRow<?= $b['id'] ?>">
                  <td><?= $b['id'] ?></td>
                  <td><?= htmlspecialchars($b['slug']) ?></td>
                  <td><?= htmlspecialchars($b['title']) ?></td>
                  <td><span class="badge bg-<?= $b['is_active'] ? 'success' : 'secondary' ?>"><?= $b['is_active'] ? 'Active' : 'Inactive' ?></span></td>
                  <td>
                    <div class="btn-group btn-group-sm" role="group">
                      <button class="btn btn-warning editBoardBtn"
                        data-id="<?= $b['id'] ?>"
                        data-slug="<?= htmlspecialchars($b['slug']) ?>"
                        data-title="<?= htmlspecialchars($b['title']) ?>"
                        data-description="<?= htmlspecialchars($b['description']) ?>"
                        data-rules="<?= htmlspecialchars($b['rules']) ?>"
                        data-status="<?= $b['is_active'] ?>"
                        data-bs-toggle="modal" data-bs-target="#editBoardModal">
                        ✏️ Edit
                      </button>
                      <button class="btn btn-danger" onclick="deleteBoard(<?= $b['id'] ?>)">🗑️ Delete</button>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="alert alert-info">No boards found.</div>
      <?php endif; ?>

      <!-- Add Board Modal -->
      <div class="modal fade" id="addBoardModal" tabindex="-1">
        <div class="modal-dialog">
          <form class="modal-content" id="addBoardForm">
            <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
            <div class="modal-header">
              <h5 class="modal-title">New Board</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <input type="text" name="slug" class="form-control mb-3" placeholder="Slug (URL identifier)" required>
              <input type="text" name="title" class="form-control mb-3" placeholder="Board title" required>
              <textarea name="description" class="form-control mb-3" placeholder="Short description"></textarea>
              <textarea name="rules" class="form-control mb-3" placeholder="Board rules (optional)"></textarea>
              <select name="is_active" class="form-select">
                <option value="1">Active</option>
                <option value="0">Inactive</option>
              </select>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary">Save</button>
            </div>
          </form>
        </div>
      </div>

      <!-- Edit Board Modal -->
      <div class="modal fade" id="editBoardModal" tabindex="-1">
        <div class="modal-dialog">
          <form class="modal-content" id="editBoardForm">
            <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
            <input type="hidden" name="id" id="editBoardId">
            <div class="modal-header">
              <h5 class="modal-title">Edit Board</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <input type="text" name="slug" id="editBoardSlug" class="form-control mb-3" required>
              <input type="text" name="title" id="editBoardTitle" class="form-control mb-3" required>
              <textarea name="description" id="editBoardDescription" class="form-control mb-3"></textarea>
              <textarea name="rules" id="editBoardRules" class="form-control mb-3"></textarea>
              <select name="is_active" id="editBoardStatus" class="form-select">
                <option value="1">Active</option>
                <option value="0">Inactive</option>
              </select>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-success">Update</button>
            </div>
          </form>
        </div>
      </div>
		          <?php include 'themes/admin/footer.php'; ?>

      <script>
        $(document).on('click', '.editBoardBtn', function () {
          $('#editBoardId').val($(this).data('id'));
          $('#editBoardSlug').val($(this).data('slug'));
          $('#editBoardTitle').val($(this).data('title'));
          $('#editBoardDescription').val($(this).data('description'));
          $('#editBoardRules').val($(this).data('rules'));
          $('#editBoardStatus').val($(this).data('status'));
        });

        $('#addBoardForm').on('submit', function (e) {
          e.preventDefault();
          $.post('forum/xhr/add_board.php', $(this).serialize(), function (res) {
            if (res.status === 'success') {
              location.reload();
            } else {
              alert(res.message || 'Failed to add board.');
            }
          }, 'json');
        });

        $('#editBoardForm').on('submit', function (e) {
          e.preventDefault();
          $.post('forum/xhr/edit_board.php', $(this).serialize(), function (res) {
            if (res.status === 'success') {
              location.reload();
            } else {
              alert(res.message || 'Failed to update board.');
            }
          }, 'json');
        });

        function deleteBoard(id) {
          if (!confirm('Are you sure you want to delete this board?')) return;
          $.post('forum/xhr/delete_board.php', {
            id: id,
            csrf_token: '<?= $csrfToken ?>'
          }, function (res) {
            if (res.status === 'success') {
              $('#boardRow' + id).fadeOut(300, function () { $(this).remove(); });
            } else {
              alert(res.message || 'Delete failed.');
            }
          }, 'json');
        }
      </script>
    </main>
  </div>
</div>
</body>
<?php $conn->close(); ?>
