<?php
require_once __DIR__ . '/../includes/auth_check_admin.php';
$db = require __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
renderAdmin('login', []);

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

$result = $conn->query("SELECT * FROM forum_word_filters ORDER BY word ASC");
$filters = $result->fetch_all(MYSQLI_ASSOC);
$resultt = $conn->query("SELECT * FROM website_info WHERE id = 1");
$info = $resultt->fetch_assoc();

$fields = ['title', 'description', 'keywords', 'website_name', 'analytics'];
$total = count($fields);
$filled = 0;

foreach ($fields as $field) {
    if (!empty(trim($info[$field]))) {
        $filled++;
    }
}

$percentage = round(($filled / $total) * 100);
$barColor = match (true) {
    $percentage < 40 => 'bg-danger',
    $percentage < 80 => 'bg-warning',
    default => 'bg-success'
};
?>
<style>
  html, body {
    height: 100%;
    margin: 0;
    padding: 0;
  }

  body {
    display: flex;
    flex-direction: column;
    
  }

  .container-fluid {
    flex: 1;
  }
</style>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<body >
<div class="container-fluid">
  <div class="row">
    <?php include 'themes/admin/navbar.php'; ?>
    <main class="col-md-10 ms-sm-auto px-md-4 py-4">
      <?php include 'themes/admin/menu.php'; ?>

      <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Word Filters</h2>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addWordModal">➕ Add New</button>
      </div>

      <div id="wordFilterResponse"></div>

      <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle">
          <thead class="table-dark">
            <tr>
              <th>ID</th>
              <th>Word</th>
              <th>Replacement</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody id="filterTable">
            <?php foreach ($filters as $f): ?>
              <tr id="filterRow<?= $f['id'] ?>">
                <td><?= $f['id'] ?></td>
                <td><?= htmlspecialchars($f['word']) ?></td>
                <td><?= htmlspecialchars($f['replacement']) ?></td>
                <td>
                  <button class="btn btn-sm btn-warning" onclick="editWord(<?= $f['id'] ?>, '<?= htmlspecialchars($f['word'], ENT_QUOTES) ?>', '<?= htmlspecialchars($f['replacement'], ENT_QUOTES) ?>')">✏️ Edit</button>
                  <button class="btn btn-sm btn-danger" onclick="deleteWord(<?= $f['id'] ?>)">🗑️ Delete</button>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <!-- Add Modal -->
      <div class="modal fade" id="addWordModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <form id="addWordForm">
              <div class="modal-header">
                <h5 class="modal-title">Add Word Filter</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body">
                <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                <div class="mb-3">
                  <label>Word</label>
                  <input type="text" name="word" class="form-control" required>
                </div>
                <div class="mb-3">
                  <label>Replacement</label>
                  <input type="text" name="replacement" class="form-control" value="***">
                </div>
              </div>
              <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Add</button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <!-- Edit Modal -->
      <div class="modal fade" id="editWordModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <form id="editWordForm">
              <div class="modal-header">
                <h5 class="modal-title">Edit Word</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body">
                <input type="hidden" name="id" id="edit_id">
                <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                <div class="mb-3">
                  <label>Word</label>
                  <input type="text" name="word" id="edit_word" class="form-control" required>
                </div>
                <div class="mb-3">
                  <label>Replacement</label>
                  <input type="text" name="replacement" id="edit_replacement" class="form-control">
                </div>
              </div>
              <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      </div>
		          <?php include 'themes/admin/footer.php'; ?>

      <script>
        $('#addWordForm').submit(function(e) {
          e.preventDefault();
          $.post('forum/xhr/add_word_filter.php', $(this).serialize(), function(res) {
            if (res.status === 'success') {
              location.reload();
            } else {
              $('#wordFilterResponse').html('<div class="alert alert-danger">' + res.message + '</div>');
            }
          }, 'json');
        });

        function editWord(id, word, replacement) {
          $('#edit_id').val(id);
          $('#edit_word').val(word);
          $('#edit_replacement').val(replacement);
          new bootstrap.Modal(document.getElementById('editWordModal')).show();
        }

        $('#editWordForm').submit(function(e) {
          e.preventDefault();
          $.post('forum/xhr/edit_word_filter.php', $(this).serialize(), function(res) {
            if (res.status === 'success') {
              location.reload();
            } else {
              $('#wordFilterResponse').html('<div class="alert alert-danger">' + res.message + '</div>');
            }
          }, 'json');
        });

        function deleteWord(id) {
          if (!confirm('Delete this word?')) return;
          $.post('forum/xhr/delete_word_filter.php', {
            id: id,
            csrf_token: '<?= $csrfToken ?>'
          }, function(res) {
            if (res.status === 'success') {
              $('#filterRow' + id).remove();
            } else {
              $('#wordFilterResponse').html('<div class="alert alert-danger">' + res.message + '</div>');
            }
          }, 'json');
        }
      </script>

    </main>
  </div>
</div>
</body>
<?php $conn->close(); ?>
