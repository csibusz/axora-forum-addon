<?php
require_once __DIR__ . '/../includes/auth_check_admin.php';
$db = require __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
renderAdmin('login', []);

if (empty($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;

$totalRes = $conn->query("SELECT COUNT(*) FROM forum_threads");
$totalRows = (int)$totalRes->fetch_row()[0];
$totalPages = (int)ceil($totalRows / $limit);

$stmt = $conn->prepare("
  SELECT t.id, t.title, t.is_sticky, t.is_locked, t.created_at,
         b.title AS board_title,
         u.name AS creator_name
  FROM forum_threads t
  LEFT JOIN forum_boards b ON t.board_id = b.id
  LEFT JOIN users u ON t.user_id = u.id
  ORDER BY t.created_at DESC
  LIMIT ? OFFSET ?
");
$stmt->bind_param("ii", $limit, $offset);
$stmt->execute();
$threads = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$resultt = $conn->query("SELECT * FROM website_info WHERE id = 1");
$info = $resultt->fetch_assoc();

$fields = ['title', 'description', 'keywords', 'website_name', 'analytics'];
$total = count($fields);
$filled = 0;

foreach ($fields as $field) {
    if (!empty(trim($info[$field]))) {
        $filled++;
    }
}

$percentage = round(($filled / $total) * 100);
$barColor = match (true) {
    $percentage < 40 => 'bg-danger',
    $percentage < 80 => 'bg-warning',
    default => 'bg-success'
};
?>


  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <style>
    body { font-family: "Segoe UI", sans-serif; }
    .table td, .table th { vertical-align: middle; }
    .badge { font-size: 0.85em; }
    .btn-group .btn { padding: 0.35rem 0.6rem; }
    .pagination .page-link { border-radius: 0.5rem; }
  </style>
<body >
<div class="container-fluid">
  <div class="row">
    <?php include 'themes/admin/navbar.php'; ?>
    <main class="col-md-10 ms-sm-auto px-md-4 py-4">
      <?php include 'themes/admin/menu.php'; ?>

      <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Forum Threads</h2>
      </div>

      <div id="threadResponseMessage"></div>

      <div class="table-responsive">
        <table class="table table-hover table-bordered align-middle shadow-sm rounded-3 bg-body">
          <thead class="table-dark">
            <tr>
              <th>ID</th>
              <th>Title</th>
              <th>Board</th>
              <th>Sticky</th>
              <th>Locked</th>
              <th>Created By</th>
              <th>Created At</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($threads as $thread): ?>
              <tr id="threadRow<?= $thread['id'] ?>">
                <td><?= $thread['id'] ?></td>
                <td><?= htmlspecialchars($thread['title']) ?></td>
                <td><?= htmlspecialchars($thread['board_title'] ?? 'Unknown') ?></td>
                <td>
                  <span class="badge <?= $thread['is_sticky'] ? 'bg-primary' : 'bg-secondary' ?>">
                    <?= $thread['is_sticky'] ? 'Yes' : 'No' ?>
                  </span>
                </td>
                <td>
                  <span class="badge <?= $thread['is_locked'] ? 'bg-danger' : 'bg-success' ?>">
                    <?= $thread['is_locked'] ? 'Yes' : 'No' ?>
                  </span>
                </td>
                <td><?= htmlspecialchars($thread['creator_name'] ?? 'System') ?></td>
                <td><?= date('Y-m-d H:i', strtotime($thread['created_at'])) ?></td>
                <td>
                  <div class="btn-group btn-group-sm">
                    <button class="btn btn-outline-primary" onclick="toggleSticky(<?= $thread['id'] ?>)">
                      <i class="bi bi-pin-angle"></i> <?= $thread['is_sticky'] ? 'Unsticky' : 'Sticky' ?>
                    </button>
                    <button class="btn btn-outline-warning" onclick="toggleLock(<?= $thread['id'] ?>)">
                      <i class="bi bi-lock<?= $thread['is_locked'] ? '-fill' : '' ?>"></i> <?= $thread['is_locked'] ? 'Unlock' : 'Lock' ?>
                    </button>
                    <button class="btn btn-outline-danger" onclick="deleteThread(<?= $thread['id'] ?>)">
                      🗑️ Delete
                    </button>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <?php if ($totalPages > 1): ?>
        <nav>
          <ul class="pagination justify-content-center">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
              <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
              </li>
            <?php endfor; ?>
          </ul>
        </nav>
      <?php endif; ?>

      <script>
        function toggleSticky(id) {
          $.post('forum/xhr/toggle_thread_sticky.php', {
            thread_id: id,
            csrf_token: '<?= $csrfToken ?>'
          }, function(res) {
            if (res.status === 'success') location.reload();
            else $('#threadResponseMessage').html('<div class="alert alert-danger">' + res.message + '</div>');
          }, 'json');
        }

        function toggleLock(id) {
          $.post('forum/xhr/toggle_thread_lock.php', {
            thread_id: id,
            csrf_token: '<?= $csrfToken ?>'
          }, function(res) {
            if (res.status === 'success') location.reload();
            else $('#threadResponseMessage').html('<div class="alert alert-danger">' + res.message + '</div>');
          }, 'json');
        }

        function deleteThread(id) {
          if (!confirm('Are you sure you want to delete this thread?')) return;
          $.post('forum/xhr/delete_thread.php', {
            thread_id: id,
            csrf_token: '<?= $csrfToken ?>'
          }, function(res) {
            if (res.status === 'success') {
              $('#threadRow' + id).remove();
            } else {
              $('#threadResponseMessage').html('<div class="alert alert-danger">' + res.message + '</div>');
            }
          }, 'json');
        }
      </script>

    </main>
			          <?php include 'themes/admin/footer.php'; ?>

  </div>
</div>
</body>
<?php $conn->close(); ?>
