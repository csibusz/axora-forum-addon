<?php
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../includes/auth_check_admin.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
  exit;
}

if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token']);
  exit;
}

$id = (int) ($_POST['id'] ?? 0);
if ($id <= 0) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid ID']);
  exit;
}

$stmt = $conn->prepare("DELETE FROM forum_word_filters WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

echo json_encode(['status' => 'success']);
