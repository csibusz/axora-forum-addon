<?php
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../includes/auth_check_admin.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
  exit;
}

$csrf = $_POST['csrf_token'] ?? '';
if ($csrf !== ($_SESSION['csrf_token'] ?? '')) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token']);
  exit;
}

$ip = trim($_POST['ip_address'] ?? '');
$reason = trim($_POST['reason'] ?? '');

if (!filter_var($ip, FILTER_VALIDATE_IP)) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid IP address']);
  exit;
}

$stmt = $conn->prepare("INSERT INTO forum_banned_ips (ip_address, reason) VALUES (?, ?)");
$stmt->bind_param("ss", $ip, $reason);
$stmt->execute();

echo json_encode(['status' => 'success']);
