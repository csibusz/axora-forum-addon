<?php
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../includes/functions.php';
require_once __DIR__ . '/../../../includes/auth_check_admin.php';
header('Content-Type: application/json');

// 1. Ellenőrzés
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
  exit;
}
if (!isset($_SESSION['csrf_token'], $_SESSION['admin_id']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token']);
  exit;
}

$thread_id = (int) ($_POST['thread_id'] ?? 0);
if ($thread_id <= 0) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid thread ID']);
  exit;
}

// 2. Lekérdezzük a címet naplózáshoz
$stmt = $conn->prepare("SELECT title FROM forum_threads WHERE id = ?");
$stmt->bind_param("i", $thread_id);
$stmt->execute();
$res = $stmt->get_result();
$stmt->close();

if ($res->num_rows === 0) {
  echo json_encode(['status' => 'error', 'message' => 'Thread not found']);
  exit;
}

$thread = $res->fetch_assoc();
$thread_title = $thread['title'];

// 3. Törlés
$stmt = $conn->prepare("DELETE FROM forum_threads WHERE id = ?");
$stmt->bind_param("i", $thread_id);
$stmt->execute();
$stmt->close();

// 4. Naplózás
$admin_id = (int) $_SESSION['admin_id'];
$action = 'delete_thread';
$details = "Thread #$thread_id: " . $thread_title;

$stmt = $conn->prepare("INSERT INTO forum_moderation_log (admin_id, action, details) VALUES (?, ?, ?)");
$stmt->bind_param("iss", $admin_id, $action, $details);
$stmt->execute();
$stmt->close();

// 5. Válasz
echo json_encode(['status' => 'success']);
