<?php
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../includes/auth_check_admin.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
  exit;
}

if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token']);
  exit;
}

$id = (int) ($_POST['id'] ?? 0);
$word = trim($_POST['word'] ?? '');
$replacement = trim($_POST['replacement'] ?? '***');

if ($id <= 0 || $word === '') {
  echo json_encode(['status' => 'error', 'message' => 'Invalid input']);
  exit;
}

$stmt = $conn->prepare("UPDATE forum_word_filters SET word = ?, replacement = ? WHERE id = ?");
$stmt->bind_param("ssi", $word, $replacement, $id);
$stmt->execute();

echo json_encode(['status' => 'success']);
