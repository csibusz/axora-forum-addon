<?php
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../includes/auth_check_admin.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
  exit;
}

if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token']);
  exit;
}

$word = trim($_POST['word'] ?? '');
$replacement = trim($_POST['replacement'] ?? '***');

if ($word === '') {
  echo json_encode(['status' => 'error', 'message' => 'Word is required']);
  exit;
}

$stmt = $conn->prepare("INSERT INTO forum_word_filters (word, replacement) VALUES (?, ?)");
$stmt->bind_param("ss", $word, $replacement);
$stmt->execute();

echo json_encode(['status' => 'success']);
