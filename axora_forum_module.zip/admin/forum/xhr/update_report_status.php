<?php
// plugins/forum/xhr/update_report_status.php
require_once __DIR__ . '/../../../includes/auth_check_admin.php';
require_once __DIR__ . '/../../../config/database.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);
if (!$data) {
    $data = $_POST; // fallback if JSON not sent
}

$report_id  = isset($data['report_id']) ? (int)$data['report_id'] : 0;
$new_status = isset($data['new_status']) ? trim($data['new_status']) : '';
$csrf_token = $data['csrf_token'] ?? '';

$valid_statuses = ['pending', 'reviewed', 'ignored'];

if ($report_id <= 0 || !in_array($new_status, $valid_statuses, true)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid parameters.']);
    exit;
}

if (!isset($_SESSION['csrf_token']) || $csrf_token !== $_SESSION['csrf_token']) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token.']);
    exit;
}

$stmt = $conn->prepare("UPDATE forum_reports SET status = ? WHERE id = ?");
$stmt->bind_param("si", $new_status, $report_id);
$success = $stmt->execute();
$stmt->close();

if ($success) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database update failed.']);
}
exit;
