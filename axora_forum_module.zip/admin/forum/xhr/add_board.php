<?php
// plugins/forum/xhr/add_board.php
require_once __DIR__ . '/../../../includes/auth_check_admin.php';
require_once __DIR__ . '/../../../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['status' => 'error', 'message' => 'Method Not Allowed']);
  exit;
}

$csrf = $_POST['csrf_token'] ?? '';
if (empty($_SESSION['csrf_token']) || $csrf !== $_SESSION['csrf_token']) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token']);
  exit;
}

$slug        = trim($_POST['slug'] ?? '');
$title       = trim($_POST['title'] ?? '');
$description = trim($_POST['description'] ?? '');
$rules       = trim($_POST['rules'] ?? '');
$is_active   = isset($_POST['is_active']) ? (int)$_POST['is_active'] : 1;

if (empty($slug) || empty($title)) {
  echo json_encode(['status' => 'error', 'message' => 'Required fields missing.']);
  exit;
}

$stmt = $conn->prepare("INSERT INTO forum_boards (slug, title, description, rules, is_active) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("ssssi", $slug, $title, $description, $rules, $is_active);
$success = $stmt->execute();
$stmt->close();

echo json_encode([
  'status' => $success ? 'success' : 'error',
  'message' => $success ? 'Board added.' : 'Database insert failed.'
]);
exit;
