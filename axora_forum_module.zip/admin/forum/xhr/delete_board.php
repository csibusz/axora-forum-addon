<?php
// plugins/forum/xhr/delete_board.php
require_once __DIR__ . '/../../../includes/auth_check_admin.php';
require_once __DIR__ . '/../../../config/database.php';

header('Content-Type: application/json');

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$csrf = $_POST['csrf_token'] ?? '';

if ($id <= 0 || empty($csrf) || $csrf !== ($_SESSION['csrf_token'] ?? '')) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
  exit;
}

$stmt = $conn->prepare("DELETE FROM forum_boards WHERE id = ?");
$stmt->bind_param("i", $id);
$success = $stmt->execute();
$stmt->close();

if ($success) {
  echo json_encode(['status' => 'success', 'message' => 'Board deleted.']);
} else {
  echo json_encode(['status' => 'error', 'message' => 'Delete failed.']);
}
exit;
