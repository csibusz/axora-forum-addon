<?php
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../includes/auth_check_admin.php';
header('Content-Type: application/json');

// Biztonsági ellenőrzések
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
  exit;
}
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token']);
  exit;
}

$thread_id = (int) ($_POST['thread_id'] ?? 0);
if ($thread_id <= 0) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid thread ID']);
  exit;
}

// Jelenlegi sticky érték lekérése
$stmt = $conn->prepare("SELECT is_sticky FROM forum_threads WHERE id = ?");
$stmt->bind_param("i", $thread_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$result) {
  echo json_encode(['status' => 'error', 'message' => 'Thread not found']);
  exit;
}

$new_value = $result['is_sticky'] ? 0 : 1;

// Frissítés
$stmt = $conn->prepare("UPDATE forum_threads SET is_sticky = ? WHERE id = ?");
$stmt->bind_param("ii", $new_value, $thread_id);
$stmt->execute();

echo json_encode(['status' => 'success']);
