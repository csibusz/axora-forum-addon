<?php
// plugins/forum/xhr/edit_board.php
require_once __DIR__ . '/../../../includes/auth_check_admin.php';
require_once __DIR__ . '/../../../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['status' => 'error', 'message' => 'Method Not Allowed']);
  exit;
}

$csrf = $_POST['csrf_token'] ?? '';
if (empty($_SESSION['csrf_token']) || $csrf !== $_SESSION['csrf_token']) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token']);
  exit;
}

$id          = (int)($_POST['id'] ?? 0);
$slug        = trim($_POST['slug'] ?? '');
$title       = trim($_POST['title'] ?? '');
$description = trim($_POST['description'] ?? '');
$rules       = trim($_POST['rules'] ?? '');
$is_active   = isset($_POST['is_active']) ? (int)$_POST['is_active'] : 1;

if ($id <= 0 || empty($slug) || empty($title)) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid or missing data.']);
  exit;
}

$stmt = $conn->prepare("UPDATE forum_boards SET slug = ?, title = ?, description = ?, rules = ?, is_active = ? WHERE id = ?");
$stmt->bind_param("ssssii", $slug, $title, $description, $rules, $is_active, $id);
$success = $stmt->execute();
$stmt->close();

echo json_encode([
  'status' => $success ? 'success' : 'error',
  'message' => $success ? 'Board updated.' : 'Update failed.'
]);
exit;
