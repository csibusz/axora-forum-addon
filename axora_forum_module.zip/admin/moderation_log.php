<?php
require_once __DIR__ . '/../includes/auth_check_admin.php';
$db = require __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
renderAdmin('login', []);

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

$stmt = $conn->prepare("
  SELECT l.id, l.action, l.details, l.created_at,
         a.username AS admin_name
  FROM forum_moderation_log l
  LEFT JOIN admins a ON l.admin_id = a.id
  ORDER BY l.created_at DESC
");
$stmt->execute();
$logs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$resultt = $conn->query("SELECT * FROM website_info WHERE id = 1");
$info = $resultt->fetch_assoc();

$fields = ['title', 'description', 'keywords', 'website_name', 'analytics'];
$total = count($fields);
$filled = 0;

foreach ($fields as $field) {
    if (!empty(trim($info[$field]))) {
        $filled++;
    }
}

$percentage = round(($filled / $total) * 100);
$barColor = match (true) {
    $percentage < 40 => 'bg-danger',
    $percentage < 80 => 'bg-warning',
    default => 'bg-success'
};
?>

<style>
  html, body {
    height: 100%;
    margin: 0;
    padding: 0;
  }

  body {
    display: flex;
    flex-direction: column;
    
  }

  .container-fluid {
    flex: 1;
  }
</style>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<body >
  <div class="container-fluid">
    <div class="row">
      <?php include 'themes/admin/navbar.php'; ?>
      <main class="col-md-10 ms-sm-auto px-md-4 py-4">
        <?php include 'themes/admin/menu.php'; ?>

        <div class="d-flex justify-content-between align-items-center mb-3">
          <h2>Moderation Log</h2>
        </div>

        <div class="table-responsive">
          <table class="table table-bordered table-striped align-middle">
            <thead class="table-dark">
              <tr>
                <th>ID</th>
                <th>Admin</th>
                <th>Action</th>
                <th>Details</th>
                <th>Created At</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($logs as $log): ?>
              <tr>
                <td><?= $log['id'] ?></td>
                <td><?= htmlspecialchars($log['admin_name'] ?? 'Unknown') ?></td>
                <td><?= htmlspecialchars($log['action']) ?></td>
                <td><?= nl2br(htmlspecialchars($log['details'])) ?></td>
                <td><?= date('Y-m-d H:i', strtotime($log['created_at'])) ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

      </main>
	  		          <?php include 'themes/admin/footer.php'; ?>

    </div>
  </div>
</body>
<?php $conn->close(); ?>
