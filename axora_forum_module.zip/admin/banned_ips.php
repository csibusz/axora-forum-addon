<?php
require_once __DIR__ . '/../includes/auth_check_admin.php';
$db = require __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
renderAdmin('login', []);

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

$result = $conn->query("SELECT * FROM forum_banned_ips ORDER BY banned_at DESC");
$banned_ips = $result->fetch_all(MYSQLI_ASSOC);
$resultt = $conn->query("SELECT * FROM website_info WHERE id = 1");
$info = $resultt->fetch_assoc();

$fields = ['title', 'description', 'keywords', 'website_name', 'analytics'];
$total = count($fields);
$filled = 0;

foreach ($fields as $field) {
    if (!empty(trim($info[$field]))) {
        $filled++;
    }
}

$percentage = round(($filled / $total) * 100);
$barColor = match (true) {
    $percentage < 40 => 'bg-danger',
    $percentage < 80 => 'bg-warning',
    default => 'bg-success'
};
?>
<style>
  html, body {
    height: 100%;
    margin: 0;
    padding: 0;
  }

  body {
    display: flex;
    flex-direction: column;
    
  }

  .container-fluid {
    flex: 1;
  }
</style>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<body >
  <div class="container-fluid">
    <div class="row">
      <?php include 'themes/admin/navbar.php'; ?>
      <main class="col-md-10 ms-sm-auto px-md-4 py-4">
        <?php include 'themes/admin/menu.php'; ?>

        <div class="d-flex justify-content-between align-items-center mb-3">
          <h2>Banned IP Addresses</h2>
          <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addIPModal">➕ Add New</button>
        </div>

        <div id="ipResponseMessage"></div>

        <div class="table-responsive">
          <table class="table table-bordered table-striped align-middle">
            <thead class="table-dark">
              <tr>
                <th>ID</th>
                <th>IP Address</th>
                <th>Reason</th>
                <th>Banned At</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody id="ipTableBody">
              <?php foreach ($banned_ips as $ip): ?>
              <tr id="ipRow<?= $ip['id'] ?>">
                <td><?= $ip['id'] ?></td>
                <td><?= htmlspecialchars($ip['ip_address']) ?></td>
                <td><?= nl2br(htmlspecialchars($ip['reason'])) ?></td>
                <td><?= $ip['banned_at'] ?></td>
                <td>
                  <button class="btn btn-sm btn-danger" onclick="deleteIP(<?= $ip['id'] ?>)">🗑️ Remove</button>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <!-- Modal: Add IP -->
        <div class="modal fade" id="addIPModal" tabindex="-1" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <form id="addIPForm">
                <div class="modal-header">
                  <h5 class="modal-title">Ban New IP</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                  <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                  <div class="mb-3">
                    <label class="form-label">IP Address</label>
                    <input type="text" name="ip_address" class="form-control" required>
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Reason</label>
                    <textarea name="reason" class="form-control" rows="3" required></textarea>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary">Ban</button>
                </div>
              </form>
            </div>
          </div>
        </div>
		          <?php include 'themes/admin/footer.php'; ?>

        <script>
        $('#addIPForm').submit(function(e) {
          e.preventDefault();
          $.post('forum/xhr/add_banned_ip.php', $(this).serialize(), function(res) {
            if (res.status === 'success') {
              location.reload();
            } else {
              $('#ipResponseMessage').html('<div class="alert alert-danger">' + res.message + '</div>');
            }
          }, 'json');
        });

        function deleteIP(id) {
          if (!confirm("Are you sure you want to remove this IP?")) return;
          $.post('forum/xhr/delete_banned_ip.php', {
            id: id,
            csrf_token: '<?= $csrfToken ?>'
          }, function(res) {
            if (res.status === 'success') {
              $('#ipRow' + id).remove();
            } else {
              $('#ipResponseMessage').html('<div class="alert alert-danger">' + res.message + '</div>');
            }
          }, 'json');
        }
        </script>

      </main>
    </div>
  </div>
</body>
<?php $conn->close(); ?>
