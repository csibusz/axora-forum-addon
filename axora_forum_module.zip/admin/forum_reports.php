<?php
require_once __DIR__ . '/../includes/auth_check_admin.php';
$db = require __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
renderAdmin('login', []);

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

$stmt = $conn->prepare("
    SELECT r.id, r.post_id, r.reason, r.created_at, r.status,
           u.name AS reporter_name,
           rp.content AS reply_content,
           t.id AS thread_id, t.title AS thread_title
    FROM forum_reports r
    LEFT JOIN users u ON r.user_id = u.id
    LEFT JOIN forum_replies rp ON r.post_id = rp.id
    LEFT JOIN forum_threads t ON rp.thread_id = t.id
    ORDER BY r.created_at DESC
");



$stmt->execute();
$reports = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$resultt = $conn->query("SELECT * FROM website_info WHERE id = 1");
$info = $resultt->fetch_assoc();

$fields = ['title', 'description', 'keywords', 'website_name', 'analytics'];
$total = count($fields);
$filled = 0;

foreach ($fields as $field) {
    if (!empty(trim($info[$field]))) {
        $filled++;
    }
}

$percentage = round(($filled / $total) * 100);
$barColor = match (true) {
    $percentage < 40 => 'bg-danger',
    $percentage < 80 => 'bg-warning',
    default => 'bg-success'
};
?>
<style>
  html, body {
    height: 100%;
    margin: 0;
    padding: 0;
  }

  body {
    display: flex;
    flex-direction: column;
    
  }

  .container-fluid {
    flex: 1;
  }
</style>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<body >
  <div class="container-fluid">
    <div class="row">
      <?php include 'themes/admin/navbar.php'; ?>
      <main class="col-md-10 ms-sm-auto px-md-4 py-4">
        <?php include 'themes/admin/menu.php'; ?>

        <div class="d-flex justify-content-between align-items-center mb-3">
          <h2>Forum Reports</h2>
        </div>

        <?php if (count($reports) > 0): ?>
          <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle">
              <thead class="table-dark">
                <tr>
                  <th>ID</th>
                  <th>Reporter</th>
                  <th>Reason</th>
                  <th>Reported Content</th>
                  <th>Thread</th>
                  <th>Status</th>
                  <th>Created</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($reports as $report): ?>
                  <tr id="reportRow<?= $report['id'] ?>">
                    <td><?= $report['id'] ?></td>
                    <td><?= htmlspecialchars($report['reporter_name'] ?? 'Unknown') ?></td>
                    <td><?= nl2br(htmlspecialchars($report['reason'])) ?></td>
                    <td><?= nl2br(htmlspecialchars(mb_strimwidth($report['reply_content'], 0, 150, '...'))) ?></td>

                    <td><a href="../index.php?page=forum/view_thread&id=<?= $report['thread_id'] ?>" target="_blank"><?= htmlspecialchars($report['thread_title']) ?></a></td>
                    <td>
                      <span class="badge bg-<?= $report['status'] === 'pending' ? 'warning' : ($report['status'] === 'reviewed' ? 'success' : 'secondary') ?>" id="status<?= $report['id'] ?>">
                        <?= ucfirst($report['status']) ?>
                      </span>
                    </td>
                    <td><?= date('Y-m-d H:i', strtotime($report['created_at'])) ?></td>
                    <td>
                      <div class="btn-group btn-group-sm" role="group">
                        <button class="btn btn-success" onclick="updateStatus(<?= $report['id'] ?>, 'reviewed')">✔️ Review</button>
                        <button class="btn btn-secondary" onclick="updateStatus(<?= $report['id'] ?>, 'ignored')">🚫 Ignore</button>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php else: ?>
          <div class="alert alert-info">No reports found.</div>
        <?php endif; ?>
		          <?php include 'themes/admin/footer.php'; ?>

        <script>
          function updateStatus(id, status) {
            $.post('forum/xhr/update_report_status.php', {
              report_id: id,
              new_status: status,
              csrf_token: '<?= $csrfToken ?>'
            }, function(response) {
              if (response.status === 'success') {
                $('#status' + id)
                  .removeClass()
                  .addClass('badge bg-' + (status === 'reviewed' ? 'success' : 'secondary'))
                  .text(status.charAt(0).toUpperCase() + status.slice(1));
              } else {
                alert(response.message || 'Error occurred.');
              }
            }, 'json');
          }
        </script>

      </main>
    </div>
  </div>
</body>
<?php $conn->close(); ?>
