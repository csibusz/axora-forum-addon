<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

ob_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth_check.php';


// Bejelentkezés ellenőrzés
if (!isset($_SESSION['user_id'])) {
  echo json_encode(['status' => 'error', 'message' => 'You must be logged in to reply.']);
  exit;
}

// Kérés típus ellenőrzés
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
  exit;
}

// CSRF token ellenőrzés
if (!isset($_POST['csrf_token'], $_SESSION['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token.']);
  exit;
}

// Bemeneti adatok
$thread_id = isset($_POST['thread_id']) ? (int)$_POST['thread_id'] : 0;
$content   = trim($_POST['content'] ?? '');
$user_id   = $_SESSION['user_id'];
$imagePath = null;
$ip        = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

// Flood védelem (30 mp)
$flood_dir = __DIR__ . '/../../storage/flood_replies/';
if (!is_dir($flood_dir)) mkdir($flood_dir, 0755, true);
$flood_key = md5($thread_id . '_' . $ip);
$flood_file = $flood_dir . $flood_key . '.txt';
$limit_seconds = 30;

if (file_exists($flood_file)) {
  $last_time = (int)file_get_contents($flood_file);
  if (time() - $last_time < $limit_seconds) {
    echo json_encode([
      'status' => 'error',
      'message' => "You're replying too quickly. Please wait {$limit_seconds} seconds."
    ]);
    exit;
  }
}
file_put_contents($flood_file, time());

// Kötelező mezők ellenőrzése
if ($thread_id <= 0 || empty($content)) {
  echo json_encode(['status' => 'error', 'message' => 'Missing data.']);
  exit;
}

// Képfeltöltés
if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
  $uploadDir = __DIR__ . '/../../uploads/forum_images/';
  if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

  $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
  $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (in_array($ext, $allowed)) {
    $filename = 'img_' . bin2hex(random_bytes(10)) . '.' . $ext;
    $target = $uploadDir . $filename;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
      $imagePath = 'uploads/forum_images/' . $filename;
    }
  }
}

// Adatbázis mentés
$stmt = $conn->prepare("INSERT INTO forum_replies (thread_id, user_id, content, image_path, ip_address) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("iisss", $thread_id, $user_id, $content, $imagePath, $ip);
$success = $stmt->execute();
$stmt->close();

if ($success) {
$stmt = $conn->prepare("UPDATE forum_threads SET updated_at = NOW() WHERE id = ?");
$stmt->bind_param("i", $thread_id);
$stmt->execute();
  unset($_SESSION['csrf_token']);
  echo json_encode(['status' => 'success', 'message' => 'Reply submitted.']);
} else {
  echo json_encode(['status' => 'error', 'message' => 'Failed to save reply.']);
}
exit;
