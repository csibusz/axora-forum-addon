<?php
// forum/index.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';

// Lekérjük az aktív fórum boardokat
$stmt = $conn->prepare("SELECT id, slug, title, description FROM forum_boards WHERE is_active = 1 ORDER BY id ASC");
$stmt->execute();
$result = $stmt->get_result();
$boards = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Thread count boardonként
$threads_stmt = $conn->prepare("
  SELECT board_id, COUNT(*) AS thread_count 
  FROM forum_threads 
  GROUP BY board_id
");
$threads_stmt->execute();
$threads_result = $threads_stmt->get_result();
$threads_counts = [];
while ($row = $threads_result->fetch_assoc()) {
  $threads_counts[$row['board_id']] = (int)$row['thread_count'];
}
$threads_stmt->close();

// Reply count boardonként (threadek alapján)
$replies_stmt = $conn->prepare("
  SELECT ft.board_id, COUNT(fr.id) AS reply_count
  FROM forum_replies fr
  JOIN forum_threads ft ON fr.thread_id = ft.id
  GROUP BY ft.board_id
");
if (!$replies_stmt) {
    die("SQL error in replies query: " . $conn->error);
}

$replies_stmt->execute();
$replies_result = $replies_stmt->get_result();
$replies_counts = [];
while ($row = $replies_result->fetch_assoc()) {
  $replies_counts[$row['board_id']] = (int)$row['reply_count'];
}
$replies_stmt->close();
?>

<?php require_once __DIR__ . '/../../includes/header.php'; ?>

<style>
html[data-bs-theme="light"] body {
  background: linear-gradient(135deg, #f0f2f5, #cfd9df);
  color: #212529;
}

html[data-bs-theme="dark"] body {
  background: #121212;
  color: #f1f1f1;
}
html[data-bs-theme="dark"] .navbar-brand {
  color: #f1f1f1;
  text-shadow: none;
}
html[data-bs-theme="dark"] .forum-board-card {
  background: #1e1e1e;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
  color: #f1f1f1;
}

html[data-bs-theme="dark"] .forum-board-card:hover {
  background-color: #2a2a2a;
  box-shadow: 0 6px 24px rgba(0, 0, 0, 0.4);
}

html[data-bs-theme="dark"] .forum-board-title {
  color: #66b2ff;
}

html[data-bs-theme="dark"] .forum-board-desc {
  color: #ccc;
}

html[data-bs-theme="dark"] .forum-board-stats {
  color: #999;
}

  .forum-board-card {
    background: #ffffff;
    border-radius: 1rem;
    padding: 1.5rem;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
  }
  .forum-board-card:hover {
    box-shadow: 0 6px 24px rgba(0, 0, 0, 0.1);
    transform: translateY(-3px);
    background-color: #f9f9f9;
  }
  .forum-board-title {
    font-size: 1.25rem;
    font-weight: 600;
    color: #0d6efd;
    margin-bottom: 0.5rem;
  }
  .forum-board-desc {
    font-size: 0.95rem;
    color: #6c757d;
  }
  .forum-board-stats {
    font-size: 0.85rem;
    color: #888;
    margin-top: 1rem;
  }
</style>

<div class="container py-5" style="padding-top: 80px;">
  <h2 class="text-center mb-5 fw-bold">📚 Forum Boards</h2>
  <div class="row justify-content-center">
    <div class="col-lg-10">
      <?php if (count($boards) > 0): ?>
        <div class="row g-4">
          <?php foreach ($boards as $board): ?>
            <?php
              $threadCount = $threads_counts[$board['id']] ?? 0;
              $replyCount = $replies_counts[$board['id']] ?? 0;
            ?>
            <div class="col-md-6">
              <a href="index.php?page=forum/view_board&slug=<?= htmlspecialchars($board['slug']) ?>" class="text-decoration-none">
                <div class="forum-board-card">
                  <div class="forum-board-title">📌 <?= htmlspecialchars($board['title']) ?></div>
                  <div class="forum-board-desc"><?= nl2br(htmlspecialchars($board['description'])) ?></div>
                  <div class="forum-board-stats">
                    <?= $threadCount ?> threads • <?= $replyCount ?> replies
                  </div>
                </div>
              </a>
            </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="alert alert-info">No forum boards found.</div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
