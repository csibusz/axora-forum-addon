<?php
// forum/view_thread.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/header.php';

$thread_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($thread_id <= 0) {
  echo '<div class="container py-5"><div class="alert alert-danger rounded shadow-sm">Invalid thread ID.</div></div>';
  require_once __DIR__ . '/../../includes/footer.php';
  exit;
}

// Thread nyitóposzt + title egy lekérdezésből
$stmt = $conn->prepare("SELECT p.id, p.content, p.image_path, p.created_at, u.name AS author, t.title AS thread_title
                        FROM forum_posts p
                        LEFT JOIN users u ON p.user_id = u.id
                        LEFT JOIN forum_threads t ON p.thread_id = t.id
                        WHERE p.thread_id = ?
                        ORDER BY p.created_at ASC");
$stmt->bind_param("i", $thread_id);
$stmt->execute();
$results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if (!$results || count($results) === 0) {
  echo '<div class="container py-5"><div class="alert alert-warning rounded shadow-sm">Thread not found.</div></div>';
  require_once __DIR__ . '/../../includes/footer.php';
  exit;
}

// Thread első bejegyzés
$first = $results[0];
unset($results[0]); // többi a hozzászólás

// Replies lekérése külön
$stmt = $conn->prepare("SELECT r.id, r.content, r.image_path, r.created_at, u.name AS author
                        FROM forum_replies r
                        LEFT JOIN users u ON r.user_id = u.id
                        WHERE r.thread_id = ?
                        ORDER BY r.created_at ASC");
$stmt->bind_param("i", $thread_id);
$stmt->execute();
$replies = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$csrf_token = $_SESSION['csrf_token'] ?? bin2hex(random_bytes(32));
$_SESSION['csrf_token'] = $csrf_token;
?>

<style>
html[data-bs-theme="light"] body {
  background: linear-gradient(135deg, #f0f2f5, #cfd9df);
  color: #212529;
}

html[data-bs-theme="dark"] body {
  background: #121212;
  color: #f1f1f1;
}
html[data-bs-theme="dark"] .navbar-brand {
  color: #f1f1f1;
  text-shadow: none;
}
html[data-bs-theme="dark"] .post-card {
  background-color: #1f1f1f;
  color: #e0e0e0;
  box-shadow: 0 4px 16px rgba(0,0,0,0.4);
}

html[data-bs-theme="dark"] .post-content {
  color: #e0e0e0;
}

html[data-bs-theme="dark"] .post-header {
  color: #bbb;
}

html[data-bs-theme="dark"] .post-author {
  color: #66b2ff;
}

html[data-bs-theme="dark"] .reply-card {
  background-color: #262626;
  color: #ddd;
  box-shadow: 0 2px 12px rgba(0,0,0,0.3);
}

html[data-bs-theme="dark"] textarea.form-control,
html[data-bs-theme="dark"] input.form-control {
  background-color: #2e2e2e;
  color: #f1f1f1;
  border-color: #444;
}

html[data-bs-theme="dark"] .modal-content {
  background-color: #2c2c2c;
  color: #eee;
}

html[data-bs-theme="dark"] .modal-header,
html[data-bs-theme="dark"] .modal-footer {
  border-color: #444;
}

html[data-bs-theme="dark"] .btn-outline-danger {
  color: #ff6b6b;
  border-color: #ff6b6b;
}

html[data-bs-theme="dark"] .btn-outline-danger:hover {
  background-color: #ff6b6b;
  color: #000;
}

  .post-card {
    background: #fff;
    border-radius: 1rem;
    padding: 1.5rem;
    box-shadow: 0 4px 16px rgba(0,0,0,0.05);
  }
  .post-header {
    font-size: 0.9rem;
    color: #6c757d;
  }
  .post-author {
    font-weight: 600;
    color: #0d6efd;
  }
  .post-content {
    font-size: 1rem;
    color: #333;
    margin-top: 1rem;
  }
  .reply-card {
    background: #f9f9f9;
    border-radius: 1rem;
    padding: 1.5rem;
    box-shadow: 0 2px 12px rgba(0,0,0,0.05);
  }
</style>

<div class="container py-5" style="padding-top: 80px;">

  <!-- THREAD NYITÓ POSZT -->
  <div class="post-card mb-5">
    <div class="d-flex justify-content-between align-items-center post-header">
      <div>🧵 <span class="post-author"><?= htmlspecialchars($first['author'] ?? 'Anonymous') ?></span></div>
      <div><?= date('Y-m-d H:i', strtotime($first['created_at'])) ?></div>
    </div>
    <div class="post-content mt-2">
      <h4 class="fw-bold"><?= htmlspecialchars($first['thread_title']) ?></h4>
      <p><?= nl2br(htmlspecialchars($first['content'])) ?></p>
      <?php if (!empty($first['image_path'])): ?>
        <div class="mt-3">
          <a href="<?= $site_url . '/' . ltrim($first['image_path'], '/') ?>" target="_blank">
            <img src="<?= $site_url . '/' . ltrim($first['image_path'], '/') ?>" class="img-fluid rounded" alt="thread image">
          </a>
        </div>
      <?php endif; ?>
    </div>
	
  </div>

  <!-- VÁLASZOK -->
 <?php foreach ($replies as $post): ?>
  <?php $replyId = $post['id'] ?? null; ?>
  <?php if (!$replyId) continue; ?>

  <div class="post-card mb-4">
    <div class="d-flex justify-content-between align-items-center post-header">
      <div>👤 <span class="post-author"><?= htmlspecialchars($post['author'] ?? 'Anonymous') ?></span></div>
      <div><?= date('Y-m-d H:i', strtotime($post['created_at'])) ?></div>
    </div>
    <div class="post-content">
      <?= nl2br(htmlspecialchars($post['content'])) ?>
    </div>

    <?php if (!empty($post['image_path'])): ?>
      <div class="mt-3">
        <a href="<?= $site_url . '/' . ltrim($post['image_path'], '/') ?>" target="_blank">
          <img src="<?= $site_url . '/' . ltrim($post['image_path'], '/') ?>" class="img-fluid rounded" alt="attachment">
        </a>
      </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['user_id'])): ?>
      <div class="mt-3">
        <button class="btn btn-outline-danger btn-sm rounded-pill"
                data-bs-toggle="modal"
                data-bs-target="#reportModal<?= $replyId ?>">
          <i class="bi bi-flag-fill me-1"></i> Report
        </button>

        <!-- Report Modal -->
        <div class="modal fade" id="reportModal<?= $replyId ?>" tabindex="-1" aria-labelledby="reportModalLabel<?= $replyId ?>" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <form class="reportForm" data-post-id="<?= $replyId ?>">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
                <input type="hidden" name="post_id" value="<?= $replyId ?>">

                <div class="modal-header">
                  <h5 class="modal-title" id="reportModalLabel<?= $replyId ?>">Report Post</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                  <label for="reason" class="form-label">Reason</label>
                  <textarea name="reason" class="form-control" required></textarea>
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                  <button type="submit" class="btn btn-danger">Submit Report</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>
<?php endforeach; ?>


  <!-- VÁLASZ BEKÜLDÉSE -->
  <?php if (isset($_SESSION['user_id'])): ?>
    <div class="reply-card mt-5">
      <h5 class="mb-3"><i class="bi bi-reply-fill me-1"></i> Reply to thread</h5>
      <form id="replyForm" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
        <input type="hidden" name="thread_id" value="<?= $thread_id ?>">

        <div class="mb-3">
          <label for="content" class="form-label">Message</label>
          <textarea name="content" id="content" class="form-control" rows="5" required></textarea>
        </div>

        <div class="mb-3">
          <label for="image" class="form-label">Optional Image</label>
          <input type="file" name="image" id="image" class="form-control" accept="image/*">
        </div>

        <button type="submit" class="btn btn-primary rounded-pill px-4">
          <i class="bi bi-send-fill me-1"></i> Submit Reply
        </button>
      </form>
    </div>
  <?php else: ?>
    <div class="alert alert-info mt-5">Please <a href="/login.php">log in</a> to reply.</div>
  <?php endif; ?>
</div>
<script>
document.querySelectorAll('.reportForm').forEach(form => {
  form.addEventListener('submit', function (e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch('plugins/forum/report_post.php', {
      method: 'POST',
      body: formData
    })
    .then(res => res.text())
    .then(text => {
      try {
        const json = JSON.parse(text);
        if (json.status === 'success') {
          alert('Reported successfully.');
          const modal = bootstrap.Modal.getInstance(this.closest('.modal'));
          modal?.hide();
        } else {
          alert(json.message || 'Report failed.');
        }
      } catch (err) {
        console.error('Invalid JSON:', err);
        console.log('Response:', text);
        alert('Unexpected response. Try again later.');
      }
    })
    .catch(err => {
      console.error('Fetch error:', err);
      alert('Network error. Please try again.');
    });
  });
});
</script>

<script>
document.getElementById('replyForm')?.addEventListener('submit', function (e) {
  e.preventDefault();

  const form = this;
  const data = new FormData(form);

  fetch('plugins/forum/reply_thread.php', {
    method: 'POST',
    body: data
  })
  .then(res => res.text()) // először textként olvassuk ki, hogy ha nem JSON, hibát jelezzen
  .then(text => {
    try {
      const json = JSON.parse(text);

      if (json.status === 'success') {
        location.reload();
      } else {
        if (json.message && json.message.toLowerCase().includes('log')) {
          alert('Your session has expired. Please log in again.');
          window.location.href = '/login.php';
        } else {
          alert(json.message || 'Failed to submit reply.');
        }
      }

    } catch (err) {
      console.error('JSON parsing failed:', err);
      console.log('Server response:', text);
      alert('Unexpected server response. Please try again later.');
    }
  })
  .catch(err => {
    console.error('Fetch error:', err);
    alert('Network error. Please try again.');
  });
});
</script>


<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
