<?php
// forum/view_board.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/header.php';

$slug = $_GET['slug'] ?? '';
$slug = preg_replace('/[^a-z0-9_-]/i', '', $slug); // csak betűk, számok, kötőjel, aláhúzás


// Lekérjük a fórum board adatait
$stmt = $conn->prepare("SELECT id, title, description, rules FROM forum_boards WHERE slug = ? AND is_active = 1 LIMIT 1");
$stmt->bind_param("s", $slug);
$stmt->execute();
$board = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$board) {
  echo '<div class="container py-5"><div class="alert alert-danger rounded shadow-sm">Board not found or inactive.</div></div>';
  require_once __DIR__ . '/../../includes/footer.php';
  exit;
}

// Pagination setup – utolsó 30 thread
$limit = 10;
$page = max(1, (int)($_GET['p'] ?? 1));
$offset = ($page - 1) * $limit;

// Összesített thread darabszám (max 30)
$count_stmt = $conn->prepare("
  SELECT COUNT(*) FROM (
    SELECT id FROM forum_threads
    WHERE board_id = ?
    ORDER BY is_sticky DESC, updated_at DESC
    LIMIT 30
  ) AS sub
");
$count_stmt->bind_param("i", $board['id']);
$count_stmt->execute();
$count_stmt->bind_result($totalThreads);
$count_stmt->fetch();
$count_stmt->close();

$totalPages = ceil($totalThreads / $limit);

// Lekérjük az utolsó 30 threadből a pagináltakat
$stmt = $conn->prepare("
  SELECT t.id, t.title, t.is_sticky, t.is_locked, t.created_at, u.name AS author,
         (SELECT COUNT(*) FROM forum_replies r WHERE r.thread_id = t.id) AS reply_count
  FROM (
    SELECT * FROM forum_threads
    WHERE board_id = ?
    ORDER BY is_sticky DESC, updated_at DESC
    LIMIT 30
  ) AS t
  LEFT JOIN users u ON t.user_id = u.id
  ORDER BY t.is_sticky DESC, t.updated_at DESC
  LIMIT ? OFFSET ?
");
$stmt->bind_param("iii", $board['id'], $limit, $offset);
$stmt->execute();
$threads = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<style>
html[data-bs-theme="light"] body {
  background: linear-gradient(135deg, #f0f2f5, #cfd9df);
  color: #212529;
}

html[data-bs-theme="dark"] body {
  background: #121212;
  color: #f1f1f1;
}
html[data-bs-theme="dark"] .navbar-brand {
  color: #f1f1f1;
  text-shadow: none;
}
html[data-bs-theme="dark"] .thread-card {
  background: #1e1e1e;
  color: #f1f1f1;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
}

html[data-bs-theme="dark"] .thread-card:hover {
  background-color: #2a2a2a;
  box-shadow: 0 6px 24px rgba(0, 0, 0, 0.5);
}

html[data-bs-theme="dark"] .thread-title {
  color: #e0e0e0;
}

html[data-bs-theme="dark"] .thread-meta {
  color: #aaa;
}

html[data-bs-theme="dark"] .reply-badge {
  background-color: #333;
  color: #ddd;
}

html[data-bs-theme="dark"] .alert.alert-warning {
  background-color: #3a3a1a;
  color: #fff;
  border-color: #5c5c1a;
}

html[data-bs-theme="dark"] .alert.alert-info {
  background-color: #1f2f3f;
  color: #d0d0ff;
  border-color: #3a4a5a;
}

  .thread-card {
    background: #ffffff;
    border-radius: 1rem;
    padding: 1.25rem 1.5rem;
    box-shadow: 0 4px 16px rgba(0,0,0,0.06);
    transition: all 0.3s ease;
  }
  .thread-card:hover {
    box-shadow: 0 6px 24px rgba(0,0,0,0.1);
    transform: translateY(-2px);
    background-color: #fdfdfd;
  }
  .thread-title {
    font-size: 1.1rem;
    font-weight: 600;
    color: #333;
  }
  .thread-meta {
    font-size: 0.85rem;
    color: #6c757d;
  }
  .reply-badge {
    background-color: #f0f0f0;
    font-size: 0.8rem;
    padding: 0.3rem 0.6rem;
    border-radius: 999px;
    font-weight: 500;
    color: #444;
  }
</style>

<div class="container py-5" style="padding-top: 80px;">
  <div class="mb-4">
    <h2 class="fw-bold mb-1">🧭 <?= htmlspecialchars($board['title']) ?></h2>
    <p class="text-muted mb-2"><?= nl2br(htmlspecialchars($board['description'])) ?></p>

    <?php if (!empty($board['rules'])): ?>
      <div class="alert alert-warning rounded shadow-sm">
        <strong>📋 Board Rules:</strong><br>
        <?= nl2br(htmlspecialchars($board['rules'])) ?>
      </div>
    <?php endif; ?>
  </div>

  <div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="fw-semibold mb-0">💬 Threads</h5>
    <a href="index.php?page=forum/new_thread&board=<?= urlencode($slug) ?>" class="btn btn-outline-primary btn-sm d-flex align-items-center gap-1 px-3 shadow-sm">
      <i class="bi bi-plus-circle-fill"></i> New Thread
    </a>
  </div>

  <?php if (count($threads) > 0): ?>
    <div class="vstack gap-3">
      <?php foreach ($threads as $thread): ?>
        <a href="index.php?page=forum/view_thread&id=<?= $thread['id'] ?>" class="text-decoration-none">
          <div class="thread-card">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <div class="thread-title mb-1">
                  <?= $thread['is_sticky'] ? '📌 ' : '' ?>
                  <?= $thread['is_locked'] ? '🔒 ' : '' ?>
                  <?= htmlspecialchars($thread['title']) ?>
                </div>
                <div class="thread-meta">
                  by <strong><?= htmlspecialchars($thread['author'] ?? 'Unknown') ?></strong> · <?= date('Y-m-d', strtotime($thread['created_at'])) ?>
                </div>
              </div>
              <div class="text-end">
                <span class="reply-badge"><?= (int)$thread['reply_count'] ?> replies</span>
              </div>
            </div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
      <nav aria-label="Board thread navigation" class="mt-4">
        <ul class="pagination justify-content-center">
          <?php if ($page > 1): ?>
            <li class="page-item">
              <a class="page-link" href="index.php?page=forum/view_board&slug=<?= urlencode($slug) ?>&p=<?= $page - 1 ?>">«</a>
            </li>
          <?php endif; ?>

          <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <li class="page-item <?= ($i === $page) ? 'active' : '' ?>">
              <a class="page-link" href="index.php?page=forum/view_board&slug=<?= urlencode($slug) ?>&p=<?= $i ?>"><?= $i ?></a>
            </li>
          <?php endfor; ?>

          <?php if ($page < $totalPages): ?>
            <li class="page-item">
              <a class="page-link" href="index.php?page=forum/view_board&slug=<?= urlencode($slug) ?>&p=<?= $page + 1 ?>">»</a>
            </li>
          <?php endif; ?>
        </ul>
      </nav>
    <?php endif; ?>
  <?php else: ?>
    <div class="alert alert-info rounded shadow-sm">No threads yet. Be the first to post!</div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
