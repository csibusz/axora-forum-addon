<?php
// forum/new_thread.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';

$slug = $_GET['board'] ?? '';

// Board ellenőrzés
$stmt = $conn->prepare("SELECT id, title FROM forum_boards WHERE slug = ? AND is_active = 1 LIMIT 1");
$stmt->bind_param("s", $slug);
$stmt->execute();
$board = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$board) {
  echo '<div class="container py-5"><div class="alert alert-danger rounded shadow-sm">Board not found.</div></div>';
  require_once __DIR__ . '/../../includes/footer.php';
  exit;
}

$csrf_token = $_SESSION['csrf_token'] ?? bin2hex(random_bytes(32));
$_SESSION['csrf_token'] = $csrf_token;

require_once __DIR__ . '/../../includes/header.php';
?>

<style>
html[data-bs-theme="light"] body {
  background: linear-gradient(135deg, #f0f2f5, #cfd9df);
  color: #212529;
}

html[data-bs-theme="dark"] body {
  background: #121212;
  color: #f1f1f1;
}
html[data-bs-theme="dark"] .navbar-brand {
  color: #f1f1f1;
  text-shadow: none;
}
html[data-bs-theme="dark"] .form-card {
  background-color: #1e1e1e;
  color: #f1f1f1;
  box-shadow: 0 4px 24px rgba(0, 0, 0, 0.4);
}

html[data-bs-theme="dark"] .form-control {
  background-color: #2a2a2a;
  color: #f1f1f1;
  border-color: #444;
}

html[data-bs-theme="dark"] .form-control::placeholder {
  color: #aaa;
}

html[data-bs-theme="dark"] .form-control:focus {
  border-color: #66b2ff;
  box-shadow: 0 0 0 0.2rem rgba(102,178,255,0.25);
}

html[data-bs-theme="dark"] .form-label {
  color: #ddd;
}

html[data-bs-theme="dark"] .btn-outline-secondary {
  color: #ddd;
  border-color: #555;
}

html[data-bs-theme="dark"] .btn-outline-secondary:hover {
  background-color: #333;
  border-color: #666;
}

  .form-card {
    background: #ffffff;
    border-radius: 1rem;
    padding: 2rem;
    box-shadow: 0 4px 24px rgba(0,0,0,0.06);
  }
  .form-label {
    font-weight: 500;
    margin-bottom: 0.3rem;
  }
  .form-control:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 0 0.2rem rgba(13,110,253,0.25);
  }
  .btn-pill {
    border-radius: 50rem;
    padding: 0.5rem 1.5rem;
  }
</style>

<div class="container py-5" style="padding-top: 80px;">
  <div class="col-md-10 col-lg-8 mx-auto">
    <div class="form-card">
      <h4 class="mb-4 fw-bold"><i class="bi bi-plus-circle me-2"></i>New Thread in: <?= htmlspecialchars($board['title']) ?></h4>

      <form id="newThreadForm" method="post" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
        <input type="hidden" name="board_id" value="<?= $board['id'] ?>">

        <div class="mb-3">
          <label for="title" class="form-label">Thread Title</label>
          <input type="text" name="title" id="title" class="form-control" placeholder="Enter your thread title..." required maxlength="255">
        </div>

        <div class="mb-3">
          <label for="content" class="form-label">Message</label>
          <textarea name="content" id="content" class="form-control" rows="6" placeholder="Write your message..." required></textarea>
		  <div class="text-end mt-1">
  <small id="charCount" class="text-muted">0 / 2000</small>
</div>

        </div>

        <div class="mb-3">
          <label for="image" class="form-label">Optional Image</label>
          <input type="file" name="image" id="image" class="form-control" accept="image/*">
        </div>

        <div class="d-flex gap-3">
          <button type="submit" class="btn btn-primary btn-pill shadow-sm">
            <i class="bi bi-send-fill me-1"></i> Post Thread
          </button>
          <a href="index.php?page=forum&view=view_board&slug=<?= urlencode($slug) ?>" class="btn btn-outline-secondary btn-pill shadow-sm">
            <i class="bi bi-arrow-left"></i> Cancel
          </a>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  document.getElementById('newThreadForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);

    fetch('plugins/forum/post_thread.php', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(data => {
      if (data.status === 'success') {
        window.location.href = 'index.php?page=forum/view_thread&id=' + data.thread_id;
      } else {
        alert(data.message || 'Something went wrong.');
      }
    })
    .catch(err => {
      console.error(err);
      alert('Request failed.');
    });
  });
  const contentInput = document.getElementById('content');
const charCount = document.getElementById('charCount');
const maxChars = 2000;

contentInput.addEventListener('input', () => {
  const len = contentInput.value.length;
  charCount.textContent = `${len} / ${maxChars}`;

  if (len > maxChars) {
    charCount.classList.remove('text-muted');
    charCount.classList.add('text-danger');
  } else if (len > maxChars * 0.9) {
    charCount.classList.remove('text-muted', 'text-danger');
    charCount.classList.add('text-warning');
  } else {
    charCount.classList.remove('text-warning', 'text-danger');
    charCount.classList.add('text-muted');
  }
});

</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
