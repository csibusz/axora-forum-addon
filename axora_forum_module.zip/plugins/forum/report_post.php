<?php
session_start();
require_once __DIR__ . '/../../config/database.php';

header('Content-Type: application/json');

// 🔒 Session ellenőrzés
if (!isset($_SESSION['user_id'])) {
  echo json_encode(['status' => 'error', 'message' => 'You must be logged in to report posts.']);
  exit;
}

// 🔒 Kérés típusának ellenőrzése
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
  exit;
}

// 🔒 CSRF ellenőrzés
$csrf = $_POST['csrf_token'] ?? '';
if (!$csrf || $csrf !== ($_SESSION['csrf_token'] ?? '')) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token.']);
  exit;
}

// 📥 Adatok beolvasása és validálás
$post_id = (int)($_POST['post_id'] ?? 0);
$reason  = trim($_POST['reason'] ?? '');
$user_id = (int)($_SESSION['user_id']);
$ip      = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

// ✅ Alap ellenőrzések
if ($post_id <= 0 || mb_strlen($reason) < 3) {
  echo json_encode(['status' => 'error', 'message' => 'Reason too short or missing post ID.']);
  exit;
}
if (mb_strlen($reason) > 1000) {
  echo json_encode(['status' => 'error', 'message' => 'Reason is too long (max 1000 chars).']);
  exit;
}

// ⛔ Flood védelem (30 mp / post / IP)
$flood_dir = __DIR__ . '/../../storage/flood_reports/';
if (!is_dir($flood_dir)) mkdir($flood_dir, 0755, true);
$flood_key = md5("report_{$post_id}_{$ip}");
$flood_file = $flood_dir . $flood_key . '.txt';
$limit_seconds = 30;

if (file_exists($flood_file)) {
  $last_time = (int)file_get_contents($flood_file);
  if (time() - $last_time < $limit_seconds) {
    echo json_encode([
      'status' => 'error',
      'message' => "You're reporting too frequently. Please wait a few seconds."
    ]);
    exit;
  }
}
file_put_contents($flood_file, time());

// ❌ Duplikált jelentés ellenőrzése (ugyanaz a felhasználó és post)
$stmt = $conn->prepare("SELECT id FROM forum_reports WHERE post_id = ? AND user_id = ?");
$stmt->bind_param("ii", $post_id, $user_id);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
  echo json_encode(['status' => 'error', 'message' => 'You already reported this post.']);
  $stmt->close();
  exit;
}
$stmt->close();

// ✅ Mentés adatbázisba
$stmt = $conn->prepare("INSERT INTO forum_reports (post_id, user_id, reason, ip_address) VALUES (?, ?, ?, ?)");
$stmt->bind_param("iiss", $post_id, $user_id, $reason, $ip);
if ($stmt->execute()) {
  echo json_encode(['status' => 'success', 'message' => 'Report submitted.']);
} else {
  echo json_encode(['status' => 'error', 'message' => 'Failed to save report.']);
}
$stmt->close();
