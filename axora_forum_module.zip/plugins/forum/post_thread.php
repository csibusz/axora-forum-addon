<?php
// forum/post_thread.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth_check.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
  exit;
}

if (!isset($_POST['csrf_token'], $_SESSION['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
  echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token.']);
  exit;
}

$title     = trim($_POST['title'] ?? '');
$content   = trim($_POST['content'] ?? '');
$board_id  = (int) ($_POST['board_id'] ?? 0);
$user_id   = $_SESSION['user_id'];
$ip        = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$imagePath = null;

if ($board_id <= 0 || empty($title) || empty($content)) {
  echo json_encode(['status' => 'error', 'message' => 'Missing required fields.']);
  exit;
}

// Kép feltöltés (ha van)
if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
  $uploadDir = __DIR__ . '/../../uploads/forum_images/';
  if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

  $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
  $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
  if (in_array($ext, $allowed)) {
    $filename = 'img_' . bin2hex(random_bytes(10)) . '.' . $ext;
    $target = $uploadDir . $filename;
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
      $imagePath = 'uploads/forum_images/' . $filename;
    }
  }
}

// Thread beszúrása
$stmt = $conn->prepare("INSERT INTO forum_threads (board_id, user_id, title) VALUES (?, ?, ?)");
$stmt->bind_param("iis", $board_id, $user_id, $title);
$success = $stmt->execute();
$thread_id = $stmt->insert_id;
$stmt->close();

if (!$success || $thread_id <= 0) {
  echo json_encode(['status' => 'error', 'message' => 'Failed to create thread.']);
  exit;
}

// Első poszt mentése
$stmt = $conn->prepare("INSERT INTO forum_posts (thread_id, user_id, content, image_path, ip_address) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("iisss", $thread_id, $user_id, $content, $imagePath, $ip);
$stmt->execute();
$stmt->close();

unset($_SESSION['csrf_token']);

echo json_encode([
  'status' => 'success',
  'thread_id' => $thread_id,
  'message' => 'Thread created successfully.'
]);
exit;
