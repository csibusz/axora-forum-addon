<?php
function load_forum_module() {
    global $PLUGIN_ROUTES;

    $PLUGIN_ROUTES['forum'] = 'plugins/forum/index.php';
    $PLUGIN_ROUTES['forum/view_board'] = 'plugins/forum/view_board.php';
    $PLUGIN_ROUTES['forum/new_thread'] = 'plugins/forum/new_thread.php';
    $PLUGIN_ROUTES['forum/post_thread'] = 'plugins/forum/post_thread.php';
    $PLUGIN_ROUTES['forum/view_thread'] = 'plugins/forum/view_thread.php';
    $PLUGIN_ROUTES['forum/reply_thread'] = 'plugins/forum/reply_thread.php';
    $PLUGIN_ROUTES['forum/report_post'] = 'plugins/forum/report_post.php';
    $PLUGIN_ROUTES['forum/recent'] = 'plugins/forum/recent.php';
	$PLUGIN_ROUTES['forum/search'] = 'plugins/forum/forum_search.php';
}

