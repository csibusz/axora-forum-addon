<?php
// forum/recent.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/header.php';

// Pagination setup
$limit = 10;
$page = max(1, (int)($_GET['p'] ?? 1));
$offset = ($page - 1) * $limit;

$totalStmt = $conn->query("SELECT COUNT(*) FROM (SELECT id FROM forum_posts ORDER BY created_at DESC LIMIT 30) AS sub");
$totalPosts = $totalStmt->fetch_row()[0];
$totalPages = ceil($totalPosts / $limit);


$stmt = $conn->prepare("
  SELECT p.id, p.content, p.created_at, p.image_path, t.title AS thread_title, t.id AS thread_id, u.name AS author
  FROM (
    SELECT * FROM forum_posts ORDER BY created_at DESC LIMIT 30
  ) AS p
  LEFT JOIN forum_threads t ON p.thread_id = t.id
  LEFT JOIN users u ON p.user_id = u.id
  ORDER BY p.created_at DESC
  LIMIT ? OFFSET ?
");

$stmt->bind_param("ii", $limit, $offset);
$stmt->execute();
$posts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<style>
html[data-bs-theme="light"] body {
  background: linear-gradient(135deg, #f0f2f5, #cfd9df);
  color: #212529;
}

html[data-bs-theme="dark"] body {
  background: #121212;
  color: #f1f1f1;
}
html[data-bs-theme="dark"] .navbar-brand {
  color: #f1f1f1;
  text-shadow: none;
}
html[data-bs-theme="dark"] .recent-post-card {
  background: rgba(30, 30, 30, 0.95);
  color: #f1f1f1;
  border: 1px solid rgba(255,255,255,0.1);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
}

html[data-bs-theme="dark"] .recent-post-content {
  color: #e0e0e0;
}

html[data-bs-theme="dark"] .recent-post-thread {
  color: #66b2ff;
}
html[data-bs-theme="dark"] .recent-post-thread:hover {
  color: #99ccff;
}

html[data-bs-theme="dark"] .pagination .page-item .page-link {
  background-color: #1f1f1f;
  color: #ddd;
  border-color: #444;
}

html[data-bs-theme="dark"] .pagination .page-item.active .page-link {
  background-color: #66b2ff;
  border-color: #66b2ff;
  color: #000;
}

html[data-bs-theme="dark"] .alert-info {
  background-color: #2a2a2a;
  color: #ddd;
  border-color: #444;
}

  .recent-post-card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 1.5rem;
    padding: 2rem;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease-in-out;
    border: 1px solid rgba(0,0,0,0.05);
  }

  .recent-post-card:hover {
    box-shadow: 0 12px 30px rgba(0, 0, 0, 0.08);
    transform: translateY(-4px);
  }

  .recent-post-header {
    font-size: 0.95rem;
    color: #6c757d;
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 0.5rem;
  }

  .recent-post-content {
    font-size: 1.05rem;
    color: #212529;
    margin-top: 1.25rem;
    line-height: 1.6;
  }

  .recent-post-thread {
    color: #0d6efd;
    font-weight: 500;
    text-decoration: none;
    transition: color 0.2s ease-in-out;
  }

  .recent-post-thread:hover {
    color: #0a58ca;
    text-decoration: underline;
  }

  .pagination .page-item .page-link {
    border-radius: 2rem;
    margin: 0 0.25rem;
    transition: all 0.2s;
  }

  .pagination .page-item.active .page-link {
    background-color: #0d6efd;
    border-color: #0d6efd;
    color: white;
    font-weight: 500;
  }

  .recent-image {
    max-height: 300px;
    object-fit: cover;
    border-radius: 1rem;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  }
</style>

<div class="container py-5" style="padding-top: 80px;">
  <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
    <h2 class="fw-bold text-gradient m-0">🕒 Latest Forum Posts</h2>
    <a href="index.php?page=forum" class="btn btn-outline-primary rounded-pill px-4 shadow-sm">
      <i class="bi bi-arrow-left"></i> Back to Forum
    </a>
  </div>

  <?php if (count($posts) > 0): ?>
    <div class="vstack gap-4 mb-5">
      <?php foreach ($posts as $post): ?>
        <div class="recent-post-card">
          <div class="recent-post-header">
            <div>👤 <strong><?= htmlspecialchars($post['author'] ?? 'Anonymous') ?></strong></div>
            <div><i class="bi bi-clock"></i> <?= date('Y-m-d H:i', strtotime($post['created_at'])) ?></div>
          </div>

          <div class="recent-post-content">
            <?= nl2br(htmlspecialchars(mb_strimwidth($post['content'], 0, 300, '...'))) ?>
          </div>

          <?php if (!empty($post['image_path'])): ?>
            <div class="mt-3">
              <a href="/<?= $post['image_path'] ?>" target="_blank">
                <img src="<?= $site_url . '/' . ltrim($post['image_path'], '/') ?>" class="img-fluid recent-image" alt="attachment">
              </a>
            </div>
          <?php endif; ?>

          <div class="mt-4">
            🔗 in <a href="index.php?page=forum/view_thread&id=<?= $post['thread_id'] ?>" class="recent-post-thread">
              "<?= htmlspecialchars($post['thread_title']) ?>"
            </a>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
      <nav aria-label="Recent post navigation">
        <ul class="pagination justify-content-center">
          <?php if ($page > 1): ?>
            <li class="page-item">
              <a class="page-link" href="index.php?page=forum/recent&p=<?= $page - 1 ?>">«</a>
            </li>
          <?php endif; ?>

          <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <li class="page-item <?= ($i === $page) ? 'active' : '' ?>">
              <a class="page-link" href="index.php?page=forum/recent&p=<?= $i ?>"><?= $i ?></a>
            </li>
          <?php endfor; ?>

          <?php if ($page < $totalPages): ?>
            <li class="page-item">
              <a class="page-link" href="index.php?page=forum/recent&p=<?= $page + 1 ?>">»</a>
            </li>
          <?php endif; ?>
        </ul>
      </nav>
    <?php endif; ?>
  <?php else: ?>
    <div class="alert alert-info rounded shadow-sm">No recent posts found.</div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
