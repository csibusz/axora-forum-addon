<?php

$now = time();
$cooldown = 5; // másodperc

if (!isset($_SESSION['last_search_time'])) {
  $_SESSION['last_search_time'] = 0;
}

if ($now - $_SESSION['last_search_time'] < $cooldown) {
  echo '<div class="container py-5" style="padding-top: 80px;">
          <div class="alert alert-danger">Please wait before performing another search.</div>
        </div>';
  require_once __DIR__ . '/../../includes/footer.php';
  exit;
}

$_SESSION['last_search_time'] = $now;

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/header.php';

$keyword = trim($_GET['q'] ?? '');
?>
<style>
html[data-bs-theme="light"] body {
  background: linear-gradient(135deg, #f0f2f5, #cfd9df);
  color: #212529;
}

html[data-bs-theme="dark"] body {
  background: #121212;
  color: #f1f1f1;
}
html[data-bs-theme="dark"] .navbar-brand {
  color: #f1f1f1;
  text-shadow: none;
}
html[data-bs-theme="dark"] .card {
  background-color: #1f1f1f;
  color: #e0e0e0;
  border-color: #333;
}

html[data-bs-theme="dark"] .card .text-muted {
  color: #aaa !important;
}

html[data-bs-theme="dark"] .alert {
  background-color: #2a2a2a;
  color: #f1f1f1;
  border-color: #444;
}

html[data-bs-theme="dark"] .btn-outline-primary {
  color: #66b2ff;
  border-color: #66b2ff;
}

html[data-bs-theme="dark"] .btn-outline-primary:hover {
  background-color: #66b2ff;
  color: #000;
}

</style>
<div class="container py-5" style="padding-top: 80px;">
  <h3 class="mb-4">🔎 Search Results for: "<?= htmlspecialchars($keyword) ?>"</h3>

  <?php
  if (mb_strlen($keyword) < 2) {
    echo '<div class="alert alert-warning">Please enter at least 2 characters.</div>';
  } else {
    $safeKeyword = mb_substr($keyword, 0, 100);
    $like = '%' . $safeKeyword . '%';

    $stmt = $conn->prepare("
      SELECT 
        p.id, p.content, p.created_at, 
        t.id AS thread_id, t.title AS thread_title, 
        u.name AS author,
        (SELECT COUNT(*) FROM forum_replies r WHERE r.thread_id = t.id) AS reply_count
      FROM forum_posts p
      LEFT JOIN forum_threads t ON p.thread_id = t.id
      LEFT JOIN users u ON p.user_id = u.id
      WHERE p.content LIKE ?
      ORDER BY p.created_at DESC
      LIMIT 50
    ");

    if (!$stmt) {
      echo '<div class="alert alert-danger">Database error: ' . htmlspecialchars($conn->error) . '</div>';
    } else {
      $stmt->bind_param("s", $like);
      $stmt->execute();
      $results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
      $stmt->close();

      if (count($results) === 0) {
        echo '<div class="alert alert-info">No results found.</div>';
      } else {
        foreach ($results as $row): ?>
          <div class="card mb-3 shadow-sm">
            <div class="card-body">
              <div class="d-flex justify-content-between mb-1">
                <div>
                  <strong><?= htmlspecialchars($row['author'] ?? 'Anonymous') ?></strong>
                  in <a href="index.php?page=forum/view_thread&id=<?= (int)$row['thread_id'] ?>" class="text-decoration-underline">
                    <?= htmlspecialchars($row['thread_title']) ?>
                  </a>
                </div>
                <small class="text-muted"><?= date('Y-m-d H:i', strtotime($row['created_at'])) ?></small>
              </div>

              <p class="mt-2"><?= nl2br(htmlspecialchars(mb_strimwidth($row['content'], 0, 300, '...'))) ?></p>

              <div class="d-flex justify-content-between align-items-center mt-3">
                <small class="text-muted"><?= (int)$row['reply_count'] ?> replies</small>
                <a href="index.php?page=forum/view_thread&id=<?= (int)$row['thread_id'] ?>" class="btn btn-sm btn-outline-primary rounded-pill">
                  View Thread
                </a>
              </div>
            </div>
          </div>
        <?php endforeach;
      }
    }
  }
  ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
